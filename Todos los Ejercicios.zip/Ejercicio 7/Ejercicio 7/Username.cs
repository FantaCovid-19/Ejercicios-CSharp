﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_7
{
    internal class Username
    {
        public string Name { get; set; }
        public string Password { get; set; }

        public Username() { }

        public Username(string name, string password)
        {
            Name = name;
            Password = password;
        }

        public Boolean Validation()
        {
            if (Name.Equals("Admin") && Password.Equals("12345"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}
